/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package introduccion.a.java;

import java.util.Scanner;

/**
 *
 * @author frank
 */
public class EjercicioCuatro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Ingrese su nombre: ");
        String nombreUsuario = input.nextLine();
        System.out.print("Ingrese su edad: ");
        int edadUsuario = input.nextInt();
        System.out.print("Su nombre es " + nombreUsuario + " y su edad es " + edadUsuario);
    }
}
