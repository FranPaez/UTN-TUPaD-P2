/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package introduccion.a.java;

import java.util.Scanner;

/**
 *
 * @author frank
 */
public class EjercicioOcho {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int divisionEntera;
        double divisionFloat;
        System.out.print("Ingrese el primer numero entero: ");
        int primerNumero = input.nextInt();
        System.out.print("Ingrese el segundo numero entero: ");
        int segundoNumero = input.nextInt();
        divisionEntera = primerNumero / segundoNumero;
        divisionFloat = divisionEntera;
        System.out.println("La division entera es: " + divisionEntera + "\n");
        System.out.println("La division flotante es: " + divisionFloat + "\n");
    }
}
