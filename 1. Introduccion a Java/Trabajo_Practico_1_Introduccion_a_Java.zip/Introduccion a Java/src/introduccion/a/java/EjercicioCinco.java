/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package introduccion.a.java;

import java.util.Scanner;

/**
 *
 * @author frank
 */
public class EjercicioCinco {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int suma, resta, division, multiplicacion;
        System.out.print("Ingrese el primer numero entero: ");
        int primerNumero = input.nextInt();
        System.out.print("Ingrese el segundo numero entero: ");
        int segundoNumero = input.nextInt();
        suma = primerNumero + segundoNumero;
        resta = primerNumero - segundoNumero;
        division = primerNumero / segundoNumero;
        multiplicacion = primerNumero * segundoNumero;
        System.out.println("El resultado de la suma entre " + primerNumero + " y " + segundoNumero + "es: " + suma + "\n");
        System.out.println("El resultado de la resta entre " + primerNumero + " y " + segundoNumero + "es: " + resta + "\n");
        System.out.println("El resultado de la division entre " + primerNumero + " y " + segundoNumero + "es: " + division + "\n");
        System.out.println("El resultado de la multiplicacion entre " + primerNumero + " y " + segundoNumero + "es: " + multiplicacion + "\n");
    }
}
